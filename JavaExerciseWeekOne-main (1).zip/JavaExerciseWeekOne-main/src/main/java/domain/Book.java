package domain;

public class Book {
}
